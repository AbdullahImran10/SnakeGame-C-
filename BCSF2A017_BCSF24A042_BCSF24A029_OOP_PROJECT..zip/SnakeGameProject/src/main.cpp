#include "menu.h"

int main(){
    ShowMenu();
    return 0;
}