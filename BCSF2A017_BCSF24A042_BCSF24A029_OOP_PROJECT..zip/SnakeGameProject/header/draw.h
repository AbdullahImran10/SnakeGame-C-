#ifndef DRAW_H
#define DRAW_H

void ClearScreen();
void DrawBorder();
void DrawSnake();
void DrawFruit();
void DrawScore();
void DrawGame();

#endif