#ifndef INPUT_H
#define INPUT_H

char GetKey();
void ProcessInput();  

#endif
